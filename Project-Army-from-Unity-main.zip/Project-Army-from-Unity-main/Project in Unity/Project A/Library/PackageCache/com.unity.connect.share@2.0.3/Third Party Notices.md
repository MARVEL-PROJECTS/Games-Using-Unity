This package contains third-party software components governed by the license(s) indicated below:
---------

Component Name: System.IO.Compression.FileSystem.dll

License Type: MIT License

License Details can be found here: https://github.com/dotnet/standard/blob/master/LICENSE.TXT