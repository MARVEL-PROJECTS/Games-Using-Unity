using UnityEditor;
using UnityEngine;

namespace Unity.InteractiveTutorials
{
    [CustomPropertyDrawer(typeof(EditorWindowType))]
    class EditorWindowTypeDrawer : FlushChildrenDrawer
    {
    }
}
