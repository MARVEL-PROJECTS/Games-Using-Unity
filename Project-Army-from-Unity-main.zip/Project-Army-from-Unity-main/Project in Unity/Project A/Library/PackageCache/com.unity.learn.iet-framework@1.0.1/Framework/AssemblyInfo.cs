using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.InternalAPIEditorBridgeDev.005")]
[assembly: InternalsVisibleTo("Assembly-CSharp-Editor-firstpass-testable")]
