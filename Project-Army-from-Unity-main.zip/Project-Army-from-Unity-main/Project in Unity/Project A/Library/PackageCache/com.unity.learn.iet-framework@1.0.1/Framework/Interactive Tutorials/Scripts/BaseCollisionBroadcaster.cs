using UnityEngine;

namespace Unity.InteractiveTutorials
{
    public abstract class BaseCollisionBroadcaster : MonoBehaviour {}
}
