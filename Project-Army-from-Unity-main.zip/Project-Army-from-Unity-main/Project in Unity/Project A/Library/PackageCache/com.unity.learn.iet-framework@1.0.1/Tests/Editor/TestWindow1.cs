using UnityEditor;
using UnityEngine;

namespace Unity.InteractiveTutorials.Tests
{
    public class TestWindow1 : EditorWindow
    {
    }
}
